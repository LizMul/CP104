"""
-------------------------------------------------------
uses of quotes
-------------------------------------------------------
Author:  liza Multani
ID:      169052574
Email:   mult2574@mylaurier.ca
__updated__ = "2023-09-21"
-------------------------------------------------------
"""
# Imports

# Constants

print('What is a "program"?')
print("A program is a sequence of instructions that specifies how to perform a computation. The details look different in different languages, but a few basic instructions appear in just about every language:\ninput: Get data from the keyboard, a file, or some other device.\noutput: Display data on the screen or send data to a file or other device.\nmath: Perform basic mathematical operations like addition and multiplication.\nconditional execution: Check for certain conditions and execute the appropriate code.\nrepetition: Perform some action repeatedly, usually with some variation.\nBelieve it or not, that's pretty much all there is to it.")
print('''"You have enemies? Good. That means you've stood up for something, sometime in your life." Winston Churchill''')
print("""Believe it or not, that's pretty much all there is to it.""")