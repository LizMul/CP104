"""
-------------------------------------------------------
cost of dosas
-------------------------------------------------------
Author:  liza Multani
ID:      169052574
Email:   mult2574@mylaurier.ca
__updated__ = "2023-09-21"
-------------------------------------------------------
"""
# Imports

# Constants

# Get the cost of one dosa from the user.
cost_per_dosa = float(input("Cost of 1 dosa: $"))
# Get the number of dosas from the user.
number_of_dosas = int(input("Number of dosa: "))
# Calculate the total cost of the dosas.
total_cost = cost_per_dosa * number_of_dosas
# Print the total cost of the dosas.
print(f"Total cost of {number_of_dosas} dosas: ${total_cost}")