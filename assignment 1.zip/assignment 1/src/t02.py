"""
-------------------------------------------------------
name/band
-------------------------------------------------------
Author:  liza Multani
ID:      169052574
Email:   mult2574@mylaurier.ca
__updated__ = "2023-09-21"
-------------------------------------------------------
"""
# Imports

# Constants

age = input("What is your age? ")
band = input("What is your favourite band? ")
print("I am " + age + " years old and " + band + " is my favourite band.")