"""
-------------------------------------------------------
length from miles to kilometeres
-------------------------------------------------------
Author:  liza Multani
ID:      169052574
Email:   mult2574@mylaurier.ca
__updated__ = "2023-09-21"
-------------------------------------------------------
"""
# Imports

# Constants

def convert_miles_to_km(miles):
  """Converts a length in miles to kilometers.
  Args:
    miles: The length in miles.
  Returns:
    The length in kilometers.
  """
  # 1 mile is equal to 1.61 kilometers.
  conversion_factor = 1.61
  # Multiply the length in miles by the conversion factor to get the length in kilometers.
  kilometers = miles * conversion_factor
  # Return the length in kilometers.
  return kilometers
# Ask the user for a length in miles.
miles = float(input("Enter a length in miles: "))
# Convert the length in miles to kilometers.
kilometers = convert_miles_to_km(miles)
# Print the length in kilometers.
print(f"{miles} miles is equal to {kilometers} kilometers.")

