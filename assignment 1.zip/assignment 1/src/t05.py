"""
-------------------------------------------------------
compound interest
-------------------------------------------------------
Author:  liza Multani
ID:      169052574
Email:   mult2574@mylaurier.ca
__updated__ = "2023-09-21"
-------------------------------------------------------
"""
# Imports

# Constants

# Get the principal amount from the user.
principal = float(input("Principal: $"))
# Get the annual interest rate from the user.
interest_rate = float(input("Interest (%): "))
# Convert the annual interest rate to a decimal.
interest_rate /= 100
# Get the number of years the amount is deposited or borrowed for.
years = int(input("Number of years: "))
# Get the number of times the interest is compounded per year.
compounding_periods = int(input("Number of times interest compounded per year: "))
# Calculate the compound interest.
balance = principal * (1 + interest_rate / compounding_periods) ** (compounding_periods * years)
# Print the balance.
print(f"Balance: ${balance:.2f}")